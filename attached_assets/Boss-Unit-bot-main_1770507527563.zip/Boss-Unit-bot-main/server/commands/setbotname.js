const { storage } = require('../storage');

async function setbotnameCommand(sock, chatId, senderId, mentionedJids, message, args, userId) {
    try {