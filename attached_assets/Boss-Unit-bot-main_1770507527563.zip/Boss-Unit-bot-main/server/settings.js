module.exports = {
    version: '2.0.0',
    botName: 'Boss',
    ownerNumber: '2349164898577',
    prefix: '.',
    pairingNumber: '2349164898577'
};